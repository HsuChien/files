#! python3
# 水泥.py - .
import pyautogui, time,random
import datetime
def stringToDate(string):
    #example '2013-07-22 09:44:15+00:00'
    dt = datetime.datetime.strptime(string, "%Y-%m-%d %H:%M")
    #print dt
    return dt

while True:
    shuinibiaohao=input('\n请输入水泥标号\n并按下enter键\n')
    jiashuishijian=input('\n请输入水泥加水时间\n如%Y-%m-%d %H:%M\n并按下enter键\n')
    jiashuishijian=stringToDate(jiashuishijian)

    shiyariqi3=(jiashuishijian + datetime.timedelta(days=3)).strftime("%Y-%m-%d %H:%M")
    print(shiyariqi3)
    kangzheqiangdu3=3.9+random.randint(0,6)/10
    kangzheqiangdu31=format(kangzheqiangdu3*0.95+random.randint(0,10)*kangzheqiangdu3/100,'.1f')
    kangzheqiangdu32=format(kangzheqiangdu3*0.95+random.randint(0,10)*kangzheqiangdu3/100,'.1f')
    kangzheqiangdu33=format(kangzheqiangdu3*0.95+random.randint(0,10)*kangzheqiangdu3/100,'.1f')
    kangyaqiangdu3=18.2+random.randint(0,13)/10
    kangyaqiangdu31=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')
    kangyaqiangdu32=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')
    kangyaqiangdu33=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')
    kangyaqiangdu34=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')
    kangyaqiangdu35=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')
    kangyaqiangdu36=format(kangyaqiangdu3*0.95+random.randint(0,10)*kangyaqiangdu3/100,'.2f')

    shiyariqi28=(jiashuishijian + datetime.timedelta(days=28)).strftime("%Y-%m-%d %H:%M")
    kangzheqiangdu28=6.3+random.randint(0,6)/10
    kangzheqiangdu281=format(kangzheqiangdu28*0.95+random.randint(0,10)*kangzheqiangdu28/100,'.1f')
    kangzheqiangdu282=format(kangzheqiangdu28*0.95+random.randint(0,10)*kangzheqiangdu28/100,'.1f')
    kangzheqiangdu283=format(kangzheqiangdu28*0.95+random.randint(0,10)*kangzheqiangdu28/100,'.1f')
    kangyaqiangdu28=36.1+random.randint(0,12)/10
    kangyaqiangdu281=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')
    kangyaqiangdu282=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')
    kangyaqiangdu283=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')
    kangyaqiangdu284=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')
    kangyaqiangdu285=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')
    kangyaqiangdu286=format(kangyaqiangdu28*0.95+random.randint(0,10)*kangyaqiangdu28/100,'.2f')


    jiaoshaliudongdu=''
    jiashuiliang=random.randint(140,142)+random.random()
    chenrudu=''
    chuningshijian=(jiashuishijian+datetime.timedelta(minutes=random.randint(160,175))).strftime("%Y-%m-%d %H:%M")
    zhongningshijian=(jiashuishijian+datetime.timedelta(minutes=random.randint(265,285))).strftime("%Y-%m-%d %H:%M")
    xidu_shiyangzhiliang=25
    xidu_shaiyuzhiliang1=0.86
    xidu_shaiyuzhiliang2=0.86
    jiaozhengxishu=''

    cx=input('\n已经准备好数据\n按下 Enter 三秒后开始填写')

            
    print('>>> 三秒内按下Ctrl+C停止程序 <<<')
    time.sleep(3)


    pyautogui.typewrite(str(stringToDate(shiyariqi3).strftime("%Y")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(shiyariqi3).strftime("%m")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(shiyariqi3).strftime("%d")))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu31))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu32))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu33))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu31))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu32))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu33))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu34))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu35))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu36))
    pyautogui.typewrite('\t')



    
    pyautogui.typewrite(str(stringToDate(shiyariqi28).strftime("%Y")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(shiyariqi28).strftime("%m")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(shiyariqi28).strftime("%d")))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu281))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu282))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangzheqiangdu283))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu281))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu282))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu283))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu284))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu285))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangyaqiangdu286))
    pyautogui.typewrite('\t')    
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')



    
    pyautogui.typewrite(str(jiashuiliang))
    pyautogui.typewrite('\t')   
    pyautogui.typewrite(str(chenrudu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')

    pyautogui.typewrite(str(jiashuishijian.strftime("%Y")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(jiashuishijian.strftime("%m")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(jiashuishijian.strftime("%d")))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(jiashuishijian.strftime("%H")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(jiashuishijian.strftime("%M")))
    pyautogui.typewrite('\t')

    

    pyautogui.typewrite(str(stringToDate(chuningshijian).strftime("%Y")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(chuningshijian).strftime("%m")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(chuningshijian).strftime("%d")))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(stringToDate(chuningshijian).strftime("%H")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(chuningshijian).strftime("%M")))
    pyautogui.typewrite('\t')



    pyautogui.typewrite(str(stringToDate(zhongningshijian).strftime("%Y")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(zhongningshijian).strftime("%m")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(zhongningshijian).strftime("%d")))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(stringToDate(zhongningshijian).strftime("%H")))
    pyautogui.typewrite(['right'])
    pyautogui.typewrite(str(stringToDate(zhongningshijian).strftime("%M")))
    pyautogui.typewrite('\t')













    
