﻿#! python3
# 钢材原材料v0.01.py - .
import pyautogui, time,random
print('石子v0.1')
print('已完成5-31.5、5-20、10-20石子的填写')
tiaoshi=input('\n按下enter开始运行\n')
while True:
    shizilijing=input('\n请输入石子粒径（如：5-20）\n并按下enter键\n')
    s90  =''
    s75_0=''
    s63_0=''
    s53_0=''
    s37_5=''
    s31_5=''
    s26_5=''
    s19_0=''
    s16_0=''
    s9_50=''
    s4_75=''
    s2_36=''
    sshyu=''
    hanni=0
    nikuai=0
    hannizongliang=0
    nikuaizongliang=0
    shiyangzongliang=1
    zongzhiliang_out=0

    x=42

    if shizilijing=='5-31.5' :
        while x==42:
            shiyangzongliang=6300
            beishu=shiyangzongliang/100
            t90=''
            t75_0=''
            t63_0=''
            t53_0=''
            t37_5=0
            t31_5=random.randint(0,5)
            t26_5=''
            t19_0=random.randint(15,45)
            t16_0=''
            t9_50=random.randint(70,90)
            t4_75=random.randint(90,100)
            t2_36=random.randint(95,100)
            tshyu=random.randint(99,100)


            e37_5=t37_5
            e31_5=t31_5-t37_5+random.random()-0.5
            e19_0=t19_0-t31_5+random.random()-0.5
            e9_50=t9_50-t19_0+random.random()-0.5
            e4_75=t4_75-t9_50+random.random()-0.5
            e2_36=t2_36-t4_75+random.random()-0.5
            eshyu=tshyu-t2_36+random.random()-0.5
            
            s37_5=0
            s31_5=int(e31_5*beishu+random.random()*10-5)
            s19_0=int(e19_0*beishu+random.random()*10-5)
            s9_50=int(e9_50*beishu+random.random()*10-5)
            s4_75=int(e4_75*beishu+random.random()*10-5)
            s2_36=int(e2_36*beishu+random.random()*10-5)
            sshyu=int(shiyangzongliang-s2_36-s4_75-s9_50-s19_0-s31_5-s37_5-random.randint(0,2))
            zongzhiliang_out=s2_36+s4_75+s9_50+s19_0+s31_5+s37_5+sshyu

            
            hannizongliang=10000
            #含泥量0.5%到0.8%
            hanni=random.randint(int(hannizongliang*0.005),int(hannizongliang*0.008))



            nikuaizongliang=10000
            #泥块含量0.1%到0.2%
            nikuai=random.randint(int(nikuaizongliang*0.001),int(nikuaizongliang*0.02))
            if sshyu>=20 and sshyu<=110 and s2_36>=0 and s4_75>=0 and s9_50>=0 and s19_0>=0 and s31_5>=0 and s37_5>=0:
                x=0

                print(sshyu,s2_36,s4_75,s9_50,s19_0,s31_5,s37_5)








        
        
    elif shizilijing=='5-20' :
        while x==42:
    
                    
            shiyangzongliang=5000
            beishu=shiyangzongliang/100
            t90=''
            t75_0=''
            t63_0=''
            t53_0=''
            t37_5=''
            t31_5=''
            t26_5=0
            t19_0=random.randint(0,10)
            t16_0=''
            t9_50=random.randint(40,80)
            t4_75=random.randint(90,100)
            t2_36=random.randint(95,100)
            tshyu=random.randint(99,100)


            e26_5=t26_5
            e19_0=t19_0-t26_5+random.random()-0.5
            e9_50=t9_50-t19_0+random.random()-0.5
            e4_75=t4_75-t9_50+random.random()-0.5
            e2_36=t2_36-t4_75+random.random()-0.5
            eshyu=tshyu-t2_36+random.random()-0.5
            
            s26_5=0
            s19_0=int(e19_0*beishu+random.random()*10-5)
            s9_50=int(e9_50*beishu+random.random()*10-5)
            s4_75=int(e4_75*beishu+random.random()*10-5)
            s2_36=int(e2_36*beishu+random.random()*10-5)
            sshyu=int(shiyangzongliang-s2_36-s4_75-s9_50-s19_0-s26_5-random.randint(0,2))
            zongzhiliang_out=s2_36+s4_75+s9_50+s19_0+s26_5+sshyu
            
            hannizongliang=6000
            #含泥量0.5%到0.8%
            hanni=random.randint(int(hannizongliang*0.005),int(hannizongliang*0.008))



            nikuaizongliang=6000
            #泥块含量0.1%到0.2%
            nikuai=random.randint(int(nikuaizongliang*0.001),int(nikuaizongliang*0.002))

            if sshyu>=20 and sshyu<=110 and s2_36>=0 and s4_75>=0 and s9_50>=0 and s19_0>=0 and s26_5>=0:
                x=0

                print(sshyu,s2_36,s4_75,s9_50,s19_0,s26_5)

    elif shizilijing=='10-20' :
        while x==42:
    
                    
            shiyangzongliang=5000
            beishu=shiyangzongliang/100
            t90=''
            t75_0=''
            t63_0=''
            t53_0=''
            t37_5=''
            t31_5=''
            t26_5=0
            t19_0=random.randint(0,15)
            t16_0=''
            t9_50=random.randint(85,100)
            t4_75=random.randint(95,100)
            t2_36=''
            tshyu=random.randint(99,100)


            e26_5=t26_5
            e19_0=t19_0-t26_5+random.random()-0.5
            e9_50=t9_50-t19_0+random.random()-0.5
            e4_75=t4_75-t9_50+random.random()-0.5
            eshyu=tshyu-t4_75+random.random()-0.5
            
            s26_5=0
            s19_0=int(e19_0*beishu+random.random()*10-5)
            s9_50=int(e9_50*beishu+random.random()*10-5)
            s4_75=int(e4_75*beishu+random.random()*10-5)
            sshyu=int(shiyangzongliang-s4_75-s9_50-s19_0-s26_5-random.randint(0,2))
            zongzhiliang_out=s4_75+s9_50+s19_0+s26_5+sshyu
            
            hannizongliang=6000
            #含泥量0.5%到0.8%
            hanni=random.randint(int(hannizongliang*0.005),int(hannizongliang*0.008))



            nikuaizongliang=6000
            #泥块含量0.1%到0.2%
            nikuai=random.randint(int(nikuaizongliang*0.001),int(nikuaizongliang*0.002))

            if sshyu>=20 and sshyu<=110 and s4_75>=0 and s9_50>=0 and s19_0>=0 and s26_5>=0:
                x=0

                print(sshyu,s4_75,s9_50,s19_0,s26_5)
#todo start
    elif shizilijing=='5-25' :
        while x==42:
    
                    
            shiyangzongliang=5000
            beishu=shiyangzongliang/100
            t90=''
            t75_0=''
            t63_0=''
            t53_0=''
            t37_5=''
            t31_5=0
            t26_5=random.randint(0,5)
            t19_0=''
            t16_0=random.randint(33,68)
            t9_50=''
            t4_75=random.randint(90,100)
            t2_36=random.randint(95,100)
            tshyu=random.randint(99,100)

            e31_5=t31_5
            e26_5=t26_5-t31_5+random.random()-0.5
            e16_0=t16_0-t26_5+random.random()-0.5
            e4_75=t4_75-t16_0+random.random()-0.5
            e2_36=t2_36-t4_75+random.random()-0.5
            eshyu=tshyu-t2_36+random.random()-0.5


            s31_5=0
            s26_5=int(e26_5*beishu+random.random()*10-5)
            s16_0=int(e16_0*beishu+random.random()*10-5)
            s4_75=int(e4_75*beishu+random.random()*10-5)
            s2_36=int(e2_36*beishu+random.random()*10-5)
            sshyu=int(shiyangzongliang-s2_36-s4_75-s16_0-s26_5-s31_5-random.randint(0,2))
            zongzhiliang_out=s2_36+s4_75+s16_0+s26_5+s31_5+sshyu

            
            hannizongliang=6000
            #含泥量0.5%到0.8%
            hanni=random.randint(int(hannizongliang*0.005),int(hannizongliang*0.008))



            nikuaizongliang=6000
            #泥块含量0.1%到0.2%
            nikuai=random.randint(int(nikuaizongliang*0.001),int(nikuaizongliang*0.002))

            if sshyu>=20 and sshyu<=110 and s2_36>=0 and s4_75>=0 and s16_0>=0 and s26_5>=0 and s31_5>=0:
                x=0

                print(sshyu,s2_36,s4_75,s16_0,s26_5,s31_5)

#todo end

#以下是共用的内容


    yasuizongliang=3000
    yasuiliang=random.randint(180,250)
    yasuishaiyu1=yasuizongliang-yasuiliang
    yasuishaiyu2=yasuishaiyu1+random.randint(-20,20)
    yasuishaiyu3=yasuishaiyu1-random.randint(-20,20)


    hannixihou1=hannizongliang-hanni
    hannixihou2=hannixihou1+random.randint(-5,5)



    nikuaixihou1=nikuaizongliang-nikuai
    nikuaixihou2=nikuaixihou1+random.randint(-3,3)



#以下开始填写表格
    
    print('总质量',zongzhiliang_out)

    

    if tiaoshi!='dev':
        


        cx=input('\n已经准备好数据\n按下 Enter 三秒后开始填写')
        if cx=='r':
            continue
        print('>>> 三秒内按下Ctrl+C停止程序 <<<')
        time.sleep(3)     


        pyautogui.typewrite(str(s90))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s75_0))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s63_0))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s53_0))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s37_5))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s31_5))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s26_5))    
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s19_0))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s16_0))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s9_50))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s4_75))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(s2_36))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(sshyu))
        pyautogui.typewrite('\t')
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(shiyangzongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(['enter'])
        pyautogui.typewrite('\t')    
        pyautogui.typewrite('\t')
        
        pyautogui.typewrite(str(yasuizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(yasuishaiyu1))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(yasuizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(yasuishaiyu2))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(yasuizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(yasuishaiyu3))
        pyautogui.typewrite('\t')    
        pyautogui.typewrite('\t')

        pyautogui.typewrite(str(hannizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(hannixihou1))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(hannizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(hannixihou2))
        pyautogui.typewrite('\t')

        
        pyautogui.typewrite(str(nikuaizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(nikuaixihou1))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(nikuaizongliang))
        pyautogui.typewrite('\t')
        pyautogui.typewrite(str(nikuaixihou2))


















    
