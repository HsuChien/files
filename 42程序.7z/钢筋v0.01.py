﻿#! python3
# 钢材原材料v0.01.py - .
import pyautogui, time,random

while True:

    gangjinzhijing=input('\n请输入钢筋直径（mm）\n并按下enter键\n')
    qufuli1=''
    qufuli2=''
    kangla1=''
    kangla2=''



    changdu=1000.0
    zhongliang1=''
    zhongliang2=''
    zhongliang3=''
    zhongliang4=''
    zhongliang5=''
    zhongliang6=''
    

    

    if gangjinzhijing=='6' :
        
        qufuli1=format(random.randint(1265,1370)/100,'.2f')
        x=(float(qufuli1)-12.65)/12.65
        kangla1=min(float(format((17.80+x*(19.00-17.80))*1.02,'.2f')),19.01)

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-12.65)/12.65
        kangla2=min(float(format((17.80+x*(19.00-17.80))*1.02,'.2f')),19.08)
        
        


        changdu=1000
        zhongliang1=random.randint(210,220)
        zhongliang2=random.randint(210,220)
        zhongliang3=random.randint(210,220)
        zhongliang4=random.randint(210,220)
        zhongliang5=random.randint(210,220)
        zhongliang6=random.randint(210,220)
        
    elif gangjinzhijing=='10' :

        qufuli1=format(random.randint(3500,3780)/100,'.2f')
        x=(float(qufuli1)-35.00)/35.00
        kangla1=min(float(format((49.00+x*(53.00-49.00))*1.05,'.2f')),53.02)

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-35.00)/35.00
        kangla2=min(float(format((49.00+x*(53.00-49.00))*1.05,'.2f')),53.08)
        
        


        changdu=1000
        zhongliang1=random.randint(595,610)
        zhongliang2=random.randint(595,610)
        zhongliang3=random.randint(595,610)
        zhongliang4=random.randint(595,610)
        zhongliang5=random.randint(595,610)
        zhongliang6=random.randint(595,610)

    elif gangjinzhijing=='8' :

        qufuli1=format(random.randint(2250,2400)/100,'.2f')
        x=(float(qufuli1)-22.50)/22.50
        kangla1=min(float(format((31.00+x*(33.50-31.00))*1.05,'.2f')),33.51)

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-22.50)/22.50
        kangla2=min(float(format((31.00+x*(33.50-31.00))*1.05,'.2f')),33.52)
        
        
        changdu=1000
        zhongliang1=random.randint(380,390)
        zhongliang2=random.randint(380,390)
        zhongliang3=random.randint(380,390)
        zhongliang4=random.randint(380,390)
        zhongliang5=random.randint(380,390)
        zhongliang6=random.randint(380,390)


    elif gangjinzhijing=='12' :

        qufuli1=format(random.randint(5000,5400)/100,'.2f')
        x=(float(qufuli1)-50.00)/50.00
        kangla1=min(float(format((68.00+x*(74.60-68.00))*1.1,'.2f')),74.61)

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-50.00)/50.00
        kangla2=min(float(format((68.00+x*(74.60-68.00))*1.1,'.2f')),74.61)
        
        
        changdu=1000
        zhongliang1=random.randint(850,880)
        zhongliang2=random.randint(850,880)
        zhongliang3=random.randint(850,880)
        zhongliang4=random.randint(850,880)
        zhongliang5=random.randint(850,880)
        zhongliang6=random.randint(850,880)


    elif gangjinzhijing=='14' :

        qufuli1=format(random.randint(6700,7000)/100,'.2f')
        x=(float(qufuli1)-67.00)/67.00
        kangla1=min(float(format((88.00+x*(99.70-88.00))*1.11,'.2f')),float(format(random.randint(9951,9972)/100,'.2f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-67.00)/67.00
        kangla2=min(float(format((88.00+x*(99.70-88.00))*1.11,'.2f')),float(format(random.randint(9951,9972)/100,'.2f')))
        
        
        changdu=1000
        zhongliang1=random.randint(1170,1190)
        zhongliang2=random.randint(1170,1190)
        zhongliang3=random.randint(1170,1190)
        zhongliang4=random.randint(1170,1190)
        zhongliang5=random.randint(1170,1190)
        zhongliang6=random.randint(1170,1190)

    elif gangjinzhijing=='16' :

        qufuli1=format(random.randint(8801,9400)/100,'.2f')
        x=(float(qufuli1)-88.01)/88.01
        kangla1=min(float(format((116.00+x*(131.00-116.00))*1.11,'.2f')),float(format(random.randint(13001,13101)/100,'.2f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.2f')
        x=(float(qufuli2)-88.01)/88.01
        kangla2=min(float(format((116.00+x*(131.00-116.00))*1.11,'.2f')),float(format(random.randint(13001,13101)/100,'.2f')))
        
        
        changdu=1000
        zhongliang1=random.randint(1525,1560)
        zhongliang2=random.randint(1525,1560)
        zhongliang3=random.randint(1525,1560)
        zhongliang4=random.randint(1525,1560)
        zhongliang5=random.randint(1525,1560)
        zhongliang6=random.randint(1525,1560)




    elif gangjinzhijing=='18' :

        qufuli1=format(random.randint(11110,12000)/100,'.1f')
        x=(float(qufuli1)-111.0)/111.0
        kangla1=min(float(format((143.0+x*(170.0-143.0))*1.13,'.1f')),float(format(random.randint(16975,17010)/100,'.1f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.1f')
        x=(float(qufuli2)-111.0)/111.0
        kangla2=min(float(format((143.0+x*(170.0-143.0))*1.13,'.1f')),float(format(random.randint(16975,17010)/100,'.1f')))
        
        
        changdu=1000
        zhongliang1=random.randint(1940,1990)
        zhongliang2=random.randint(1940,1990)
        zhongliang3=random.randint(1940,1990)
        zhongliang4=random.randint(1940,1990)
        zhongliang5=random.randint(1940,1990)
        zhongliang6=random.randint(1940,1990)


    elif gangjinzhijing=='20' :

        qufuli1=format(random.randint(13900,14600)/100,'.1f')
        x=(float(qufuli1)-139.0)/139.0
        kangla1=min(float(format((185.0+x*(205.0-185.0))*1.13,'.1f')),float(format(random.randint(20204,20505)/100,'.1f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.1f')
        x=(float(qufuli2)-139.0)/139.0
        kangla2=min(float(format((185.0+x*(205.0-185.0))*1.13,'.1f')),float(format(random.randint(20204,20505)/100,'.1f')))
        
        
        changdu=1000
        zhongliang1=random.randint(2400,2450)
        zhongliang2=random.randint(2400,2450)
        zhongliang3=random.randint(2400,2450)
        zhongliang4=random.randint(2400,2450)
        zhongliang5=random.randint(2400,2450)
        zhongliang6=random.randint(2400,2450)

    elif gangjinzhijing=='22' :

        qufuli1=format(random.randint(16700,18000)/100,'.1f')
        x=(float(qufuli1)-167.0)/167.0
        kangla1=min(float(format((225.0+x*(250.0-225.0))*1.13,'.1f')),float(format(random.randint(24204,25005)/100,'.1f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.1f')
        x=(float(qufuli2)-167.0)/167.0
        kangla2=min(float(format((225.0+x*(250.0-225.0))*1.13,'.1f')),float(format(random.randint(24204,25005)/100,'.1f')))
        
        
        changdu=1000
        zhongliang1=random.randint(2890,2930)
        zhongliang2=random.randint(2890,2930)
        zhongliang3=random.randint(2890,2930)
        zhongliang4=random.randint(2890,2930)
        zhongliang5=random.randint(2890,2930)
        zhongliang6=random.randint(2890,2930)


    elif gangjinzhijing=='25' :

        qufuli1=format(random.randint(21500,23000)/100,'.1f')
        x=(float(qufuli1)-215.0)/215.0
        kangla1=min(float(format((280.0+x*(326.0-280.0))*1.13,'.1f')),float(format(random.randint(31104,32601)/100,'.1f')))

        qufuli2=format(float(qufuli1)-0.15+random.randint(0,5)/10,'.1f')
        x=(float(qufuli2)-215.0)/215.0
        kangla2=min(float(format((280.0+x*(326.0-280.0))*1.13,'.1f')),float(format(random.randint(31104,32601)/100,'.1f')))
        
        
        changdu=1000
        zhongliang1=random.randint(3770,3800)
        zhongliang2=random.randint(3770,3800)
        zhongliang3=random.randint(3770,3800)
        zhongliang4=random.randint(3770,3800)
        zhongliang5=random.randint(3770,3800)
        zhongliang6=random.randint(3770,3800)


#以下开始填写表格


    cx=input('\n已经准备好数据\n按下 Enter 三秒后开始填写')

            
    print('>>> 三秒内按下Ctrl+C停止程序 <<<')
    time.sleep(3)     


    pyautogui.typewrite(str(qufuli1))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangla1))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(qufuli2))

    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(kangla2))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(['down'])
    pyautogui.typewrite(['up'])
    pyautogui.typewrite(['up'])
    pyautogui.typewrite(['up'])
    
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')    
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')    
    
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(changdu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(zhongliang1))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(changdu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(zhongliang2))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(changdu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(zhongliang3))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(changdu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(zhongliang4))
    pyautogui.typewrite('\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(changdu))
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(zhongliang5))






















    
