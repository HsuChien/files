﻿#! python3
# formFiller.py - Automatically fills in the form.
import pyautogui, time,random


while True:
    input('按下 Enter 开始')
    print('>>> 3 SECOND PAUSE TO LET USER PRESS CTRL-C <<<')
    time.sleep(3)

    # Set these to the correct coordinates for your computer.
    #nameField = (648, 319)
    #submitButton = (651, 817)
    #submitButtonColor = (75, 141, 249)
    #submitAnotherLink = (760, 224)



    a=0
    b=random.randint(23,35)
    c=random.randint(33,43)

    e=random.randint(122,133)
    f=random.randint(136,153)
    g=random.randint(37,50)
    h=random.randint(15,28)
    after=random.randint(499,500)
    d=after-a-b-c-e-f-g-h

    i=random.randint(6,14)
    j=i+random.randint(0,4)-2
    k=500-i
    l=500-j
    m=random.randint(198,199)
    n=random.randint(198,199)
    x=(a+b+c+d+e)/500
    while x<0.41 or x>0.70 or b>50 :
        continue
#    pyautogui.typewrite(str(a) + '\t')
    pyautogui.typewrite('\t')
    pyautogui.typewrite(str(b) + '\t')
    pyautogui.typewrite(str(c) + '\t')
    pyautogui.typewrite(str(d) + '\t')
    pyautogui.typewrite(str(e) + '\t')
    pyautogui.typewrite(str(f) + '\t')
    pyautogui.typewrite(str(g) + '\t')
    pyautogui.typewrite(str(h) + '\t')



    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
    print(g)
    print(h)
    print(after)
    print('----')

    a=0
    b=random.randint(23,35)
    c=random.randint(33,43)

    e=random.randint(122,133)
    f=random.randint(136,153)
    g=random.randint(37,50)
    h=random.randint(15,28)
    after=random.randint(497,500)
    d=after-a-b-c-e-f-g-h

    while x<0.41 or x>0.70 or b>50:
        continue
    pyautogui.typewrite(str(a) + '\t')
    pyautogui.typewrite(str(b) + '\t')
    pyautogui.typewrite(str(c) + '\t')
    pyautogui.typewrite(str(d) + '\t')
    pyautogui.typewrite(str(e) + '\t')
    pyautogui.typewrite(str(f) + '\t')
    pyautogui.typewrite(str(g) + '\t')
    pyautogui.typewrite(str(h) + '\t')


    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
    print(g)
    print(h)
    print(after)

    # Fill out the Name field.

    pyautogui.typewrite(str(500) + '\t')

    pyautogui.typewrite(str(500) + '\t')
    pyautogui.typewrite(str(k) + '\t')
    pyautogui.typewrite(str(500) + '\t')
    pyautogui.typewrite(str(l) + '\t')

    pyautogui.typewrite(str(200) + '\t')
    pyautogui.typewrite(str(m) + '\t')
    pyautogui.typewrite(str(200) + '\t')
    pyautogui.typewrite(str(n) + '\t')

    pyautogui.typewrite('\t')
    
# TODO: Give the user a chance to kill the script.
# TODO: Wait until the form page has loaded.
# TODO: Fill out the Name Field.
# TODO: Fill out the Greatest Fear(s) field.
# TODO: Fill out the Source of Wizard Powers field.
# TODO: Fill out the RoboCop field.
# TODO: Fill out the Additional Comments field.
# TODO: Click Submit.
# TODO: Wait until form page has loaded.
# TODO: Click the Submit another response link.
