﻿#! python3
#coding=utf-8
# formFiller.py - Automatically fills in the form.


import pyautogui,time,random

import requests
res = requests.get('https://raw.githubusercontent.com/HsuChien/files/master/key.py')
res.raise_for_status()
playFile = open('key.py', 'wb')
for chunk in res.iter_content(100):
    playFile.write(chunk)    
playFile.close()
import key
print('填写试块抗压强度v0.4.1')
allstart_time=time.time()
k=0
while key.x_key():
    

    y=input('\n标养请输入1，同养请输入2 输入quit退出程序\n')
    start_time=time.time()
    y=str(y)
    cx=0
    
    i=0
    dadaobaifenshu_in=3
    dadaobaifenshu_out=0
    if y=='quit':
        break
    if y=='猜数字'or y=='caishuzi':


        x=random.randint(0,99)
        i=0

        while True:
            i=i+1
            a=input('输入0-99的整数\n')
            if a=='q':
                break
            a=float(a)
            #print(x,a)
            if a<x:
                print(i)
                print('小了\n')
            elif a>x:
                print(i)
                print('大了\n')
            elif a==x:
                print(i)
                print('猜对了\n')
                
                break
        continue

    if y=='剪刀石头布':

        def jiandaoshitoubu(l,r):
            #\n0：剪刀✂\n1：石头\n2：布
            
            if l==r:
                print('平局！')
                
            elif l==0 and r==1:
                print('输了！')
                
            elif l==0 and r==2:
                print('恭喜你，赢了！')

                
            elif l==1 and r==0:
                print('恭喜你，赢了！')

                
            elif l==1 and r==2:
                print('输了！')
                
            elif l==2 and r==0:
                print('输了！')
                
            elif l==2 and r==1:
                print('恭喜你，赢了！')

                
            elif True:
                print('请重试！')        




            
        while True:
            i=0

            x=random.randint(0,2)
            
            user_x=input('请输入：\n0：剪刀✂\n1：石头\n2：布\n')
            if user_x=='q':
                break
            jiandaoshitoubu(float(user_x),x)
            print(user_x,x,'\n')
            i=i+1
            time.sleep(2)
        continue











        

    cx=input('\n请输入试块强度数值：\n')
    if cx=='r':
        continue

    cx=float(cx)

    chongxin=42
    while y=='1':
        if dadaobaifenshu_in==3:
            dadaobaifenshu_in=round(random.randint(1080,1220)/10,2)              
        
        #print(dadaobaifenshu_in)
        qiangdudengji=cx/0.095
        
        
        while (abs(float(dadaobaifenshu_in)-float(dadaobaifenshu_out)))>=0.1 :
            cx1=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            cx2=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            cx3=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            #print('\n') 
            #print(cx1,cx2,cx3)
            #print('\n达到设计强度：')
            dadaobaifenshu_out=(cx1+cx2+cx3)*100.0/3.0/qiangdudengji
            #print(dadaobaifenshu_out)
            
            i=i+1



        print('\n')
        print(cx1,cx2,cx3)
        print('\n')
        dadaobaifenshu_out=(cx1+cx2+cx3)*100.0/3.0/qiangdudengji
        print('达到:',dadaobaifenshu_out,'%')
        chongxin=input('\n输入3重新随机生成数据，如需要特定百分数请直接输入数值\n输入enter确认数据\n')
        if chongxin=='r':
            break
            
        elif chongxin=='':
            print('\n>>> 请在2秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
            time.sleep(2)
        

            pyautogui.typewrite(str(cx1) + '\t')
            pyautogui.typewrite(str(cx2) + '\t')
            pyautogui.typewrite(str(cx3) + '\t')
            end_time=time.time()
            k=k+1

            print('\n一共',k,'组，用时：',end_time-allstart_time,'秒')
            print('\n平均每组用时：',(end_time-allstart_time)/k,'\n')

            break

            
        elif chongxin!='':
            dadaobaifenshu_out=0
            dadaobaifenshu_in=float(chongxin)
            continue

                
            
        
    while y=='2':
        if dadaobaifenshu_in==3:
            
            dadaobaifenshu_in=round(random.randint(1080,1160)/10,2)
        #print(dadaobaifenshu_in)
        qiangdudengji=cx*0.88/0.095
        
        while (abs(float(dadaobaifenshu_in)-float(dadaobaifenshu_out)))>=0.1 :
            cx1=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            cx2=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            cx3=round((random.randint(int(dadaobaifenshu_in*0.9*qiangdudengji/100),int(dadaobaifenshu_in*1.1*qiangdudengji/100))+random.random()),1)
            dadaobaifenshu_out=(cx1+cx2+cx3)*100.0/3.0/qiangdudengji
            i=i+1
            


        
        print('\n')  
        print(cx1,cx2,cx3)
        print('\n')  
        print('达到:',(cx1+cx2+cx3)*100.0/3.0/qiangdudengji,'%')
        chongxin=input('\n输入3重新随机生成数据，如需要特定百分数请直接输入数值\n输入enter确认数据\n')

        if chongxin=='r':
            break
        elif chongxin=='':
            print('\n>>> 请在2秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
            time.sleep(2)
            
            pyautogui.typewrite(str(cx1) + '\t')
            pyautogui.typewrite(str(cx2) + '\t')
            pyautogui.typewrite(str(cx3) + '\t')
            end_time=time.time()
            k=k+1
            print('\n一共',k,'组，用时：',end_time-allstart_time,'秒')
            print('\n平均每组用时：',(end_time-allstart_time)/k,'\n')

            
            break
        elif chongxin!='':
            dadaobaifenshu_out=0
            dadaobaifenshu_in=float(chongxin)
            continue




    


        
        
        
        

