﻿#! python3
# 建设用砂.py - 自动填表，可选细度模数范围[2.0,3.3].
import pyautogui, time,random
import key

while True:

    M=input('\n请输入砂子的 细度模数值 并按下enter键\n不输入将默认在2.5-2.9自动选择')
    MI=2.7
    if M=='' or M=='0' :
        MI=round(random.randint(255,285)/100,2)
    elif M!='':
        MI=float(M)
    print('细度模数')
    print(MI)
    
    print('正在计算中')
    time.sleep(1)
    cx=42
    MO=0.0
    m=''
    i=1
    while m!=0 :

        while (abs(float(MI)-float(MO)))>=0.01:
            #t150是150um累计筛余百分数
            #此处可调整4.75砂子的百分比
            t950=random.randint(0,0)
            t475=random.randint(0,7)
            t236=random.randint(max(t475+3,0),25)
            t118=random.randint(max(t236+2,10),49)
            t600=random.randint(max(t118+3,44),70)
            t300=random.randint(max(t600+2,72),92)
            t150=random.randint(max(t300+1,92),99)
            tshy=100

            MO=round(((t236+t118+t600+t300+t150)-5*t475)/(100-t475),2)
            
            print(i)
            print(MO)
            i=i+1
            

        #e150是150um分计筛余百分数
        e950=t950
        e475=t475-t950+random.random()-0.5

        e236=t236-t475+random.random()-0.5
        e118=t118-t236+random.random()-0.5
        e600=t600-t118+random.random()-0.5
        e300=t300-t600+random.random()-0.5
        e150=t150-t300+random.random()-0.5
        eshy=tshy-t150+random.random()-0.5

        s950=int(e950*5)
        s475=int(e475*5)
        s236=int(e236*5)
        s118=int(e118*5)
        s600=int(e600*5)
        s300=int(e300*5)
        s150=int(e150*5)
        sshy=500-s950-s475-s236-s118-s600-s300-s150

        s9501=0
        x9501=s9501
        s9502=0
        x9502=s9502
        s4751=int(s475+random.random()*10-5)
        s4752=int(s475+random.random()*10-5)
        if M=='0':
            s4751=0
            s4752=0
        s2361=max(int(s236+random.random()*10-5),0)
        s2362=max(int(s236+random.random()*10-5),0)
        s1181=int(s118+random.random()*10-5)
        s1182=int(s118+random.random()*10-5)
        s6001=int(s600+random.random()*10-5)
        s6002=int(s600+random.random()*10-5)
        s3001=int(s300+random.random()*10-5)
        s3002=int(s300+random.random()*10-5)
        s1501=int(s150+random.random()*10-5)
        s1502=int(s150+random.random()*10-5)
        sshy1=random.randint(499,500)-s9501-s4751-s2361-s1181-s6001-s3001-s1501
        sshy2=random.randint(499,500)-s9502-s4752-s2362-s1182-s6002-s3002-s1502

#        if sshy1>50 or sshy1<30 or sshy2>50 or (s3001<s6001 and s1501) or (s6001<s1181 and s3001)or sshy2<30 or s4751>49 or s4752>49 or s118<s236 :
#            continue

        hn1=random.randint(6,14)
        hn2=hn1+random.randint(0,4)-2
        hn1=500-hn1
        hn2=500-hn2
        nk1=random.randint(198,199)
        nk2=random.randint(198,199)



        t9501=s9501/5
        t4751=t9501+s4751/5
        t2361=t4751+s2361/5
        t1181=t2361+s1181/5
        t6001=t1181+s6001/5
        t3001=t6001+s3001/5
        t1501=t3001+s1501/5
        tshy1=t1501+sshy1/5
        
        t9502=s9502/5
        t4752=t9502+s4752/5
        t2362=t4752+s2362/5
        t1182=t2362+s1182/5
        t6002=t1182+s6002/5
        t3002=t6002+s3002/5
        t1502=t3002+s1502/5
        tshy2=t1502+sshy2/5
     

        
        t950=round((t9501+t9502)/2)
        t475=round((t4751+t4752)/2)
        t236=round((t2361+t2362)/2)
        t118=round((t1181+t1182)/2)
        t600=round((t6001+t6002)/2)
        t300=round((t3001+t3002)/2)
        t150=round((t1501+t1502)/2)
        tshy=round((tshy1+tshy2)/2)




        
        print('共计')
        print(i-1)
        print('次\n')
        print('筛孔尺寸 筛余1 筛余2 累计筛余')        
        print('9.50mm',s9501,s9502,t950)
        print('4.75mm',s4751,s4751,t475)
        print('2.36mm',s2361,s2362,t236)
        print('1.18mm',s1181,s1182,t118)
        print(' 600um',s6001,s6002,t600)
        print(' 300um',s3001,s3002,t300)
        print(' 150um',s1501,s1502,t150)
        print('剩余量',sshy1,sshy2,tshy)


        print('\n细度模数：')
        print(MO)
        cx=input('\n已经准备好数据\n按下 Enter 三秒后开始填写，且下一组不再询问细度模数\n按下r立刻重新输入细度模数\n按下n开始输入并询问下一组的细度模数')

        if cx=='r':
            break
#            continue
        
        
        print('>>> 三秒内按下Ctrl+C停止程序 <<<')
        time.sleep(3)
        pyautogui.typewrite(str(s9501) + '\t')
        pyautogui.typewrite(str(s4751) + '\t')
        pyautogui.typewrite(str(s2361) + '\t')
        pyautogui.typewrite(str(s1181) + '\t')
        pyautogui.typewrite(str(s6001) + '\t')
        pyautogui.typewrite(str(s3001) + '\t')
        pyautogui.typewrite(str(s1501) + '\t')
        pyautogui.typewrite(str(sshy1) + '\t')
            
        pyautogui.typewrite(str(s9502) + '\t')
        pyautogui.typewrite(str(s4752) + '\t')
        pyautogui.typewrite(str(s2362) + '\t')
        pyautogui.typewrite(str(s1182) + '\t')
        pyautogui.typewrite(str(s6002) + '\t')
        pyautogui.typewrite(str(s3002) + '\t')
        pyautogui.typewrite(str(s1502) + '\t')
        pyautogui.typewrite(str(sshy2) + '\t')


        pyautogui.typewrite(str(500) + '\t')

        pyautogui.typewrite(str(500) + '\t')
        pyautogui.typewrite(str(hn1) + '\t')
        pyautogui.typewrite(str(500) + '\t')
        pyautogui.typewrite(str(hn2) + '\t')

        pyautogui.typewrite(str(200) + '\t')
        pyautogui.typewrite(str(nk1) + '\t')
        pyautogui.typewrite(str(200) + '\t')
        pyautogui.typewrite(str(nk2) + '\t')

        pyautogui.typewrite('\t')
        if cx=='n':
            break

        





    

