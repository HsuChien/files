﻿#! python3
#coding=utf-8
# formFiller.py - Automatically fills in the form.
import pyautogui,time,random

while True:


    
    cx=input('请输入砂浆试块强度数值：\n')
    cx=float(cx)
    yang=cx/0.27
    
    while True:


        cx1=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
        cx2=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
        cx3=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
        print(cx1,cx2,cx3)
        print((cx1+cx2+cx3)*100*0.27/3.0/cx)
        chongxin=input('输入enter确认数据\n')
        if chongxin=='':
            print('>>> 请在3秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
            time.sleep(3)
        

            pyautogui.typewrite(str(cx1) + '\t')
            pyautogui.typewrite(str(cx2) + '\t')
            pyautogui.typewrite(str(cx3) + '\t')
            

            pyautogui.typewrite('\t')
            break
        elif chongxin!='':
            continue

        
        

        
        
        
        

