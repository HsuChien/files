#! python3
#coding=utf-8
# formFiller.py - Automatically fills in the form.
import pyautogui,time,random



#print('\n>>> 请在2秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
#time.sleep(2)
while True:
    i=0
    cx=input('\n请先打开ASTM软件做好准备，\n并在下方输入强度数值后按下enter（例如C30输入30）：\n')

    spam = []

    if cx=='25':
        print('将在10秒后开始填写数字,\n请切换到ASTM软件界面')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(30,34)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )

    elif cx=='30':
        print('将在10秒后开始填写数字')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(34,38)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )


    elif cx=='35':
        print('将在10秒后开始填写数字')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(38,41)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )

    elif cx=='40':
        print('将在10秒后开始填写数字')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(39,43)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )

    elif cx=='45':
        print('将在10秒后开始填写数字')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(42,45)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )



    elif cx=='50':
        print('将在10秒后开始填写数字')
        time.sleep(10)
        while i< 160:


            shuzi = random.randint(43,46)
            spam = spam + [shuzi]

            i=i+1
        for shuzi in spam:
            pyautogui.typewrite(str(shuzi) )





           
            


#            pyautogui.typewrite('\t')

                


    


        
        
        
        

