﻿#! python3
#coding=utf-8
# formFiller.py - Automatically fills in the form.
import pyautogui,time,random

while True:

    y=input('标养请输入1，同养请输入2，输入其它值退出程序\n')
    y=str(y)
    cx=0




    if y=='1':
        
        cx=input('请输入试块强度数值：\n')
        cx=float(cx)
        yang=cx*22.5
        
        for i in range(1):
            cx1=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
            cx2=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
            cx3=round((random.randint(int(1.10*yang),int(1.20*yang))+random.random()),1)
            print('>>> 请在5秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
            time.sleep(5)

            pyautogui.typewrite(str(cx1) + '\t')
            pyautogui.typewrite(str(cx2) + '\t')
            pyautogui.typewrite(str(cx3) + '\t')
            print(cx1,cx2,cx3)


            pyautogui.typewrite('\t')
            i=i+1
        
    elif y=='2':
        cx=input('请输入试块强度数值：\n')
        cx=float(cx)
        yang=cx*0.88*22.5
        
        for i in range(1):
            cx1=round((random.randint(int(1.10*yang),int(1.16*yang))+random.random()),1)
            cx2=round((random.randint(int(1.10*yang),int(1.16*yang))+random.random()),1)
            cx3=round((random.randint(int(1.10*yang),int(1.16*yang))+random.random()),1)
               
            print('>>> 请在5秒内选择要输入的位置<<<\n>>> 按下 CTRL+C 强制退出程序<<<')
            time.sleep(5)
            
            pyautogui.typewrite(str(cx1) + '\t')
            pyautogui.typewrite(str(cx2) + '\t')
            pyautogui.typewrite(str(cx3) + '\t')
            print(cx1,cx2,cx3)


            pyautogui.typewrite('\t')
            i=i+1
        

    elif (y!='0')or(y!='1'):
        print('程序已退出')
        break

    


        
        
        
        

